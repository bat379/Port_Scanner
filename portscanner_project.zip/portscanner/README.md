# Smart Port Scanner v2.0 — Professional Edition

A production-grade, modular network port scanner with **async + threaded scanning**, **banner grabbing**, **service fingerprinting**, **OS detection**, **vulnerability analysis**, **WHOIS/DNS recon**, and **HTML/JSON/CSV reports**.

> ⚠️ **Ethical use only.** Only scan systems you own or have explicit permission to test.

---

## Features

| Feature | Details |
|---|---|
| **TCP Scanning** | Threaded (default) or Async (`asyncio`) engine |
| **UDP Scanning** | Best-effort scan of common UDP ports |
| **Banner Grabbing** | Protocol-aware probes (HTTP HEAD, passive SSH/FTP/SMTP) |
| **Fingerprinting** | 20+ regex patterns → service + version |
| **OS Detection** | Heuristic guess from banner strings |
| **Vulnerability Detection** | 15+ port rules + banner CVE patterns |
| **Risk Classification** | CRITICAL / HIGH / MEDIUM / LOW / INFO |
| **WHOIS + DNS Recon** | Zero external dependencies (pure socket) |
| **Reports** | HTML dashboard · JSON · CSV |
| **Logging** | `scan.log` + optional stderr debug |
| **Unit Tests** | 25+ tests covering all core modules |
| **CLI Tool** | `pip install .` → `portscan` command |

---

## Installation

```bash
# Clone / download the project
cd portscanner

# No external dependencies needed — uses Python stdlib only
python scanner.py --help

# OR install as a global CLI tool
pip install .
portscan --help
```

---

## Usage

```bash
# Basic scan (threaded, ports 1-1000, HTML report)
python scanner.py --target scanme.nmap.org --ports 1-1000

# Async mode — much faster for large ranges
python scanner.py --target 192.168.1.1 --ports 1-65535 --mode async

# Full scan: TCP + UDP + all reports
python scanner.py --target 10.0.0.1 --ports 1-500 --udp --output all

# Speed tuned: 300 threads, 0.5s timeout
python scanner.py --target example.com --ports 1-1000 --threads 300 --timeout 0.5

# Skip recon for speed, JSON output only
python scanner.py --target 10.0.0.1 --ports 80-443 --no-recon --output json

# Verbose debug output
python scanner.py --target scanme.nmap.org --ports 1-100 --verbose
```

---

## Project Structure

```
portscanner/
├── scanner.py              ← Main CLI entry point
├── setup.py                ← pip install support
├── README.md
├── core/
│   ├── scanner.py          ← TCPScanner, AsyncScanner, udp_scan
│   ├── banner.py           ← grab_banner, fingerprint, guess_os
│   ├── vuln.py             ← analyze, Finding, risk_summary
│   └── recon.py            ← resolve_host, dns_records, whois_raw
├── reports/
│   ├── html_report.py      ← generate_html, save_html
│   └── exporters.py        ← save_json, save_csv
└── tests/
    └── test_scanner.py     ← 25+ unit tests
```

---

## Running Tests

```bash
# Using unittest (stdlib)
python -m unittest discover tests/ -v

# Using pytest (if installed)
pip install pytest
pytest tests/ -v
```

---

## Sample Output

```
  ╔═══════════════════════════════════════════════════════╗
  ║     SMART PORT SCANNER  v2.0  —  Professional        ║
  ╚═══════════════════════════════════════════════════════╝

[*] Resolved scanme.nmap.org → 45.33.32.156
[*] DNS: A=45.33.32.156  PTR=scanme.nmap.org
[*] WHOIS: Country=US  Network=LINODE-US

── TCP Scan (THREAD) — 1–1000 ──────────────────────
  [OPEN]  Port 22     → OpenSSH  v8.9p1
          ↳ SSH-2.0-OpenSSH_8.9p1 Ubuntu
  [OPEN]  Port 80     → Apache  v2.4.54
          ↳ HTTP/1.1 200 OK

── Vulnerability Analysis ──────────────────────────
  [INFO]  Port 80  HTTP (Unencrypted)
          ↳ Serving content over plain HTTP.

Scan complete in 4.73s
Open TCP ports : 2
```

---

## CV Description

> "Developed a professional-grade multithreaded and asynchronous port scanner in Python featuring banner grabbing, intelligent service fingerprinting, OS detection heuristics, and an automated vulnerability detection engine with CVE mapping and risk classification. Implemented WHOIS/DNS reconnaissance using raw sockets, modular plugin-based architecture, structured logging, and multi-format reporting (HTML, JSON, CSV). Included a full unit test suite and pip-installable CLI interface — demonstrating practical knowledge of network security, socket programming, asyncio, and software engineering best practices."

---

## Ethical Notice

Only use this tool on:
- Your own systems and networks
- Systems you have **written permission** to test
- Authorized targets like `scanme.nmap.org`

**Never** scan third-party systems without consent. Unauthorised scanning may be illegal in your jurisdiction.
